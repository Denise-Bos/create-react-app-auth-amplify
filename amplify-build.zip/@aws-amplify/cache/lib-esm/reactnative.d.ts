import { Cache, AsyncStorageCache } from './AsyncStorageCache';
export { Cache, AsyncStorageCache };
/**
 * @deprecated use named import
 */
export default Cache;
