'use strict';

module.exports = require('./lib-esm/index.js');
