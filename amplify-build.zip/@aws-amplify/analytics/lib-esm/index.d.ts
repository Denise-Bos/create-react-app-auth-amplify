import { Analytics } from './Analytics';
import { AnalyticsProvider } from './types';
/**
 * @deprecated use named import
 */
export default Analytics;
export { AnalyticsProvider, Analytics };
export * from './Providers';
