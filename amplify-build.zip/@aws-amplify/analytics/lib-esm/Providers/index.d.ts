export { AWSPinpointProvider } from './AWSPinpointProvider';
export { AWSKinesisProvider } from './AWSKinesisProvider';
export { AWSKinesisFirehoseProvider } from './AWSKinesisFirehoseProvider';
export { AmazonPersonalizeProvider } from './AmazonPersonalizeProvider';
