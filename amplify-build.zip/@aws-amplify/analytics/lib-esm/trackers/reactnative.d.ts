import { SessionTracker } from './SessionTracker-rn';
declare class EventTracker {
    constructor(tracker: any, opts: any);
}
declare class PageViewTracker {
    constructor(tracker: any, opts: any);
}
export { EventTracker, PageViewTracker, SessionTracker };
