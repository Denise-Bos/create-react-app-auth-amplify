import { SessionTracker } from './SessionTracker-rn';
var EventTracker = /** @class */ (function () {
    function EventTracker(tracker, opts) {
    }
    return EventTracker;
}());
var PageViewTracker = /** @class */ (function () {
    function PageViewTracker(tracker, opts) {
    }
    return PageViewTracker;
}());
export { EventTracker, PageViewTracker, SessionTracker };
//# sourceMappingURL=reactnative.js.map