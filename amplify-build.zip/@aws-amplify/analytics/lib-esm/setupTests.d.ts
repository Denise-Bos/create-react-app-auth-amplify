declare const anyGlobal: any;
