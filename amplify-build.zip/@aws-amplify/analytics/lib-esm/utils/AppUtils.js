var isAppInForeground = function () {
    return true;
};
export { isAppInForeground };
//# sourceMappingURL=AppUtils.js.map