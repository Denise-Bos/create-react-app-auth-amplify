declare const isAppInForeground: () => boolean;
export { isAppInForeground };
