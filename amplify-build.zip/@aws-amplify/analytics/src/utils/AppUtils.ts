const isAppInForeground = () => {
	return true;
};

export { isAppInForeground };
