'use strict';

const build = require('../../scripts/build');

build(process.argv[2], process.argv[3]);
