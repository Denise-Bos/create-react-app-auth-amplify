import { AuthModeStrategy } from '../types';
export declare const defaultAuthStrategy: AuthModeStrategy;
