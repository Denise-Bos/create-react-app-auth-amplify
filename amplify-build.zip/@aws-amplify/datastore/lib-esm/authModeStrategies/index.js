export { defaultAuthStrategy } from './defaultAuthStrategy';
export { multiAuthStrategy } from './multiAuthStrategy';
//# sourceMappingURL=index.js.map