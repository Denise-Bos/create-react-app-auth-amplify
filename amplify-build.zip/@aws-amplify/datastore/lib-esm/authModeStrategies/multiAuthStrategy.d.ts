import { AuthModeStrategy } from '../types';
export declare const multiAuthStrategy: AuthModeStrategy;
