import AsyncStorageAdapter from '../AsyncStorageAdapter';
var getDefaultAdapter = function () {
    return AsyncStorageAdapter;
};
export default getDefaultAdapter;
//# sourceMappingURL=index.native.js.map