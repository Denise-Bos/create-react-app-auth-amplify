import { Adapter } from '..';
declare const getDefaultAdapter: () => Adapter;
export default getDefaultAdapter;
