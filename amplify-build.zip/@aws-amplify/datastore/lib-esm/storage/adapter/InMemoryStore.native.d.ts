/// <reference types="@react-native-async-storage/async-storage" />
export declare function createInMemoryStore(): import("@react-native-async-storage/async-storage").AsyncStorageStatic;
