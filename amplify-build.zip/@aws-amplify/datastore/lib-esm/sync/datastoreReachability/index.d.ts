export declare const ReachabilityMonitor: import("zen-observable-ts").default<{
    online: boolean;
}>;
