import { Reachability } from '@aws-amplify/core';
export var ReachabilityMonitor = new Reachability().networkMonitor();
//# sourceMappingURL=index.js.map