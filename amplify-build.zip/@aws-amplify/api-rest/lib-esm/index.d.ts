import { RestAPI } from './RestAPI';
export { RestAPI, RestAPIClass } from './RestAPI';
export { RestClient } from './RestClient';
export default RestAPI;
