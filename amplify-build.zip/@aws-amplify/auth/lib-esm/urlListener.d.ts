declare const _default: (callback: any) => void;
export default _default;
