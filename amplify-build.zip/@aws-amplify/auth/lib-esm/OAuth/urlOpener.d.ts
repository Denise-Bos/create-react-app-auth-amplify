export declare const launchUri: (url: string) => Promise<Window>;
