export declare const launchUri: (url: any) => any;
