export declare const setState: (state: string) => void;
export declare const getState: () => string;
export declare const setPKCE: (private_key: string) => void;
export declare const getPKCE: () => string;
export declare const clearAll: () => void;
