declare const _default: (callback: any) => Promise<void>;
export default _default;
