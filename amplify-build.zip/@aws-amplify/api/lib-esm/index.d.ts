import { API } from './API';
export { API, APIClass } from './API';
export { graphqlOperation, GraphQLResult, GraphQLAuthError, GRAPHQL_AUTH_MODE, } from '@aws-amplify/api-graphql';
export default API;
