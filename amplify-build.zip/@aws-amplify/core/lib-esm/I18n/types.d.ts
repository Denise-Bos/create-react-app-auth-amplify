export declare class I18nOptions {
    language: any;
}
