export * from './AWSCloudWatchProvider';
//# sourceMappingURL=index.js.map