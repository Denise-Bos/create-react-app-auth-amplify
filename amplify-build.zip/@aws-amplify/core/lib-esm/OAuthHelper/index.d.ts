import { GoogleOAuth as GoogleOAuthClass } from './GoogleOAuth';
import { FacebookOAuth as FacebookOAuthClass } from './FacebookOAuth';
export declare const GoogleOAuth: GoogleOAuthClass;
export declare const FacebookOAuth: FacebookOAuthClass;
