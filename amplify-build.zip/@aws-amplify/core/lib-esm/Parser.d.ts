import { AmplifyConfig } from './types';
export declare const parseMobileHubConfig: (config: any) => AmplifyConfig;
/**
 * @deprecated use per-function export
 */
export declare class Parser {
    static parseMobilehubConfig: (config: any) => AmplifyConfig;
}
/**
 * @deprecated use per-function export
 */
export default Parser;
