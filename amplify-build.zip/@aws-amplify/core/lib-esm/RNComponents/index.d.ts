export declare const Linking: {};
export declare const AppState: {
    addEventListener: (action: any, handler: any) => any;
};
export declare const AsyncStorage: any;
