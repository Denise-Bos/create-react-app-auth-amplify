export declare function urlSafeEncode(str: string): string;
export declare function urlSafeDecode(hex: string): string;
