export declare const Platform: {
    userAgent: string;
    product: string;
    navigator: any;
    isReactNative: boolean;
};
export declare const getAmplifyUserAgent: () => string;
/**
 * @deprecated use named import
 */
export default Platform;
