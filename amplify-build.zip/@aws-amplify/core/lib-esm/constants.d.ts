export declare const INTERNAL_AWS_APPSYNC_PUBSUB_PROVIDER: string | symbol;
export declare const INTERNAL_AWS_APPSYNC_REALTIME_PUBSUB_PROVIDER: string | symbol;
export declare const USER_AGENT_HEADER = "x-amz-user-agent";
