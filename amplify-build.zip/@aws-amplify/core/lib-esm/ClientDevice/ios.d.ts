export declare const clientInfo: () => {
    platform: string;
    version: string;
    appVersion: string;
    make: string;
    model: string;
};
