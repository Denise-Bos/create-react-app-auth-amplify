export declare function missingConfig(name: string): Error;
export declare function invalidParameter(name: string): Error;
