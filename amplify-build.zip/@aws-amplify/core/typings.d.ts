declare module '*.json' {
	export const version: any;
}
